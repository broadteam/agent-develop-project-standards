#!/usr/bin/env python3
"""Disposable Linux namespace/chroot probe. Synthetic data only; no Agent client."""
from __future__ import annotations
import os
import pathlib
import selectors
import json
import re
import shutil
import signal
import socket
import subprocess
import tempfile
import threading
import time
import platform

ENV = {"PATH": "/usr/bin:/bin", "HOME": "/nonexistent", "LANG": "C", "LC_ALL": "C", "HOST_SECRET_CANARY": "host-secret-env-must-not-enter-client"}
UID_INSIDE = 65534
GID_INSIDE = 65534


def require_binary(name: str) -> str:
    value = shutil.which(name)
    if not value:
        raise RuntimeError(f"required executable not found: {name}")
    return value


def copy_runtime(binary: str, root: pathlib.Path) -> None:
    target = root / binary.lstrip("/")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(binary, target)
    ldd = subprocess.run(["ldd", binary], text=True, capture_output=True, check=False)
    if ldd.returncode != 0:
        raise RuntimeError(f"ldd failed for {binary}: {ldd.stderr.strip()}")
    libraries: set[str] = set()
    for line in ldd.stdout.splitlines():
        match = re.search(r"=>\s+(/[^\s]+)|^\s*(/[^\s]+)", line)
        if match:
            libraries.add(match.group(1) or match.group(2))
    for library in sorted(libraries):
        src = pathlib.Path(library)
        if not src.exists():
            continue
        dst = root / library.lstrip("/")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src.resolve(), dst)


def bootstrap_rootfs(base: pathlib.Path, host_canary_name: str) -> tuple[pathlib.Path, pathlib.Path]:
    root = base / "rootfs"
    work = base / "work"
    for part in ("bin", "usr/bin", "work", "proc", "sys", "tmp", "dev"):
        (root / part).mkdir(parents=True, exist_ok=True)
    work.mkdir(mode=0o777, exist_ok=True)

    busybox = require_binary("busybox")
    setpriv = require_binary("setpriv")
    copy_runtime(busybox, root)
    # Place the multi-call binary under /bin because all applet links resolve there.
    shutil.copy2(busybox, root / "bin" / "busybox")
    copy_runtime(setpriv, root)

    for applet in ("sh", "ash", "cat", "grep", "touch", "id", "sleep", "nc", "test", "env"):
        link = root / "bin" / applet
        if not link.exists():
            link.symlink_to("busybox")

    (root / "input.txt").write_text("synthetic-read-only-fixture\n", encoding="utf-8")
    (root / "input.txt").chmod(0o444)
    # Deliberately hostile traversal target. chroot must clamp resolution at its root.
    (root / "escape").symlink_to(f"../../../../tmp/{host_canary_name}")

    probe = r'''set -eu
[ "$(id -u)" = "65534" ] || { echo "FAIL uid"; exit 31; }
[ "$(id -g)" = "65534" ] || { echo "FAIL gid"; exit 32; }
priv="$(/usr/bin/setpriv --dump)"
echo "$priv"
echo "$priv" | grep -q 'no_new_privs: 1' || { echo "FAIL no_new_privs"; exit 33; }
echo "$priv" | grep -q 'Capability bounding set: \[none\]' || { echo "FAIL capability bounding set"; exit 34; }
[ -z "${HOST_SECRET_CANARY+x}" ] || { echo "FAIL inherited environment"; exit 35; }
if touch /read-only-must-fail; then echo "FAIL writable root"; exit 36; else echo "PASS read-only-root"; fi
if cat /tmp/host-canary; then echo "FAIL host canary visible"; exit 37; else echo "PASS host-path-hidden"; fi
if cat /escape; then echo "FAIL symlink escaped chroot"; exit 38; else echo "PASS symlink-contained"; fi
[ ! -e /proc/1/status ] || { echo "FAIL proc exposed"; exit 39; }
[ ! -e /sys/kernel ] || { echo "FAIL sysfs exposed"; exit 40; }
echo "PASS proc-sys-hidden"
[ "$(cat /input.txt)" = "synthetic-read-only-fixture" ] || { echo "FAIL input read"; exit 41; }
echo "PASS read-only-input"
touch /work/scratch-write
[ -f /work/scratch-write ] || { echo "FAIL scratch write"; exit 42; }
echo "PASS dedicated-scratch-write"
if echo probe | nc -w 1 127.0.0.1 PORT; then echo "FAIL host-loopback-reachable"; exit 43; else echo "PASS host-loopback-isolated"; fi
'''
    (root / "probe.sh").write_text(probe, encoding="utf-8")
    (root / "probe.sh").chmod(0o444)
    # Only the private scratch directory is writable by the namespace's unprivileged uid.
    work.chmod(0o777)
    # Root filesystem and content are read-only; namespace bind mounts are applied at run time.
    for p in sorted(root.rglob("*"), reverse=True):
        try:
            if p.is_symlink():
                continue
            mode = p.stat().st_mode
            if p.is_dir():
                p.chmod(0o555)
            else:
                p.chmod(0o555 if mode & 0o111 else 0o444)
        except FileNotFoundError:
            pass
    root.chmod(0o555)
    return root, work


def namespace_command(unshare: str, root: pathlib.Path, work: pathlib.Path, command: str, *, kill_child: bool = False) -> list[str]:
    uid = os.geteuid()
    gid = os.getegid()
    args = [unshare]
    if kill_child:
        args.append("--kill-child=KILL")
    args += [
        "--user",
        "--map-users", f"0:{uid}:1",
        "--map-users", "1:1:65535",
        "--map-groups", f"0:{gid}:1",
        "--map-groups", "1:1:65535",
        "--mount", "--net", "--pid", "--fork",
        "sh", "-c",
        f"set -eu; mount --make-rprivate /; mount --bind \"$1\" \"$1\"; mount -o remount,ro,bind \"$1\"; mount --bind \"$2\" \"$1/work\"; mount -o remount,rw,bind \"$1/work\"; env -i HOME=/tmp PATH=/bin:/usr/bin /usr/bin/prlimit --core=0 --cpu=10 --fsize=1048576 --nofile=64 --nproc=64 --as=268435456 -- /usr/sbin/chroot \"$1\" /usr/bin/setpriv --reuid={UID_INSIDE} --regid={GID_INSIDE} --clear-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs -- /bin/sh -c \"$3\"",
        "scp-namespace", str(root), str(work), command,
    ]
    return args



def run_capture_limited(command: list[str], *, max_bytes: int, timeout_seconds: float) -> tuple[bytes, bool, bool, int]:
    """Capture at most max_bytes; terminate namespace owner on overflow/timeout."""
    proc = subprocess.Popen(command, env=ENV, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, close_fds=True, start_new_session=True)
    assert proc.stdout is not None
    fd = proc.stdout.fileno()
    os.set_blocking(fd, False)
    selector = selectors.DefaultSelector()
    selector.register(fd, selectors.EVENT_READ)
    output = bytearray()
    overflow = False
    timed_out = False
    deadline = time.monotonic() + timeout_seconds
    while selector.get_map():
        if time.monotonic() >= deadline:
            timed_out = True
            break
        events = selector.select(timeout=0.05)
        for key, _ in events:
            try:
                chunk = os.read(key.fd, 2048)
            except BlockingIOError:
                continue
            if not chunk:
                selector.unregister(key.fd)
                continue
            remaining = max_bytes - len(output)
            if len(chunk) > remaining:
                if remaining > 0:
                    output.extend(chunk[:remaining])
                overflow = True
                break
            output.extend(chunk)
        if overflow:
            break
    if overflow or timed_out:
        try:
            proc.send_signal(signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=2)
    selector.close()
    proc.stdout.close()
    return bytes(output), overflow, timed_out, proc.returncode


def redact_synthetic_secret(raw: bytes) -> bytes:
    # Fixture-only marker redaction; not a general secret-scanning service.
    return re.sub(rb"SCP_SYNTHETIC_SECRET_TOKEN=[^\s\r\n]+",
                  b"SCP_SYNTHETIC_SECRET_TOKEN=[REDACTED]", raw)


def write_owner_record(owner_file: pathlib.Path, run_id: str, root: pathlib.Path, work: pathlib.Path) -> None:
    owner_file.parent.mkdir(parents=True, exist_ok=True)
    owner_file.write_text(json.dumps({
        "run_id": run_id,
        "root": str(root.resolve()),
        "work": str(work.resolve()),
        "state": "active",
    }, sort_keys=True), encoding="utf-8")
    owner_file.chmod(0o600)


def cleanup_owned_paths(base: pathlib.Path, owner_file: pathlib.Path, run_id: str,
                        root: pathlib.Path, work: pathlib.Path, *, inject_failure: bool = False) -> str:
    """Only cleanup paths bound to an owner record; quarantine on injected failure."""
    base_real = base.resolve(strict=True)
    root_real = root.resolve(strict=True)
    work_real = work.resolve(strict=True)
    if root.is_symlink() or work.is_symlink():
        raise RuntimeError("cleanup target is a symlink")
    for target in (root_real, work_real):
        if target == base_real or not target.is_relative_to(base_real):
            raise RuntimeError("cleanup target escaped owned base")
        if target.is_symlink():
            raise RuntimeError("cleanup target is a symlink")
    record = json.loads(owner_file.read_text(encoding="utf-8"))
    if record.get("run_id") != run_id or record.get("root") != str(root_real) or record.get("work") != str(work_real):
        raise RuntimeError("cleanup ownership proof mismatch")
    if record.get("state") != "active":
        raise RuntimeError("resource is not active/reusable")
    if inject_failure:
        quarantine = base / "quarantine"
        quarantine.mkdir(mode=0o700, exist_ok=True)
        qroot = quarantine / f"{run_id}-root"
        qwork = quarantine / f"{run_id}-work"
        root_real.rename(qroot)
        work_real.rename(qwork)
        record.update({"state": "quarantined", "reason": "synthetic_cleanup_failure_injection",
                       "quarantine_root": str(qroot), "quarantine_work": str(qwork)})
        owner_file.write_text(json.dumps(record, sort_keys=True), encoding="utf-8")
        return "quarantined"
    shutil.rmtree(root_real)
    shutil.rmtree(work_real)
    owner_file.unlink()
    return "succeeded"


def owner_record_allows_reuse(owner_file: pathlib.Path) -> bool:
    if not owner_file.exists():
        return False
    try:
        return json.loads(owner_file.read_text(encoding="utf-8")).get("state") == "active"
    except (OSError, ValueError, TypeError):
        return False

def main() -> int:
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise RuntimeError("this first backend probe currently supports Linux x86_64 only")
    if os.geteuid() != 0:
        raise RuntimeError("this environment probe requires root to create the test UID/GID map; no fallback is silently assumed")
    unshare = require_binary("unshare")
    chroot = require_binary("chroot")
    # The execution image places chroot at /usr/sbin/chroot; use resolved path.
    chroot_path = chroot
    if chroot_path != "/usr/sbin/chroot":
        raise RuntimeError(f"unexpected chroot path: {chroot_path}")

    with tempfile.TemporaryDirectory(prefix="scp-linux-sandbox-") as td:
        base = pathlib.Path(td)
        host_canary = base / "host-canary"
        host_canary.write_text("host-secret-canary-must-not-be-visible\n", encoding="utf-8")
        root, work = bootstrap_rootfs(base, host_canary.name)
        run_id = "scp-linux-probe-001"
        owner_file = base / "owners" / "owner.json"
        write_owner_record(owner_file, run_id, root, work)

        # A listener exists in the host network namespace. The sandbox must not reach it.
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        listener.settimeout(0.1)
        port = listener.getsockname()[1]
        accepted: list[bool] = []

        stop_accept = threading.Event()

        def accept_loop() -> None:
            while not stop_accept.is_set():
                try:
                    conn, _ = listener.accept()
                    accepted.append(True)
                    conn.close()
                except socket.timeout:
                    continue
                except OSError:
                    break

        thread = threading.Thread(target=accept_loop, daemon=True)
        thread.start()

        probe_text = (root / "probe.sh").read_text(encoding="utf-8").replace("PORT", str(port))
        (root / "probe.sh").write_text(probe_text, encoding="utf-8")
        (root / "probe.sh").chmod(0o444)
        primary_cmd = namespace_command(unshare, root, work, ". /probe.sh")
        primary = subprocess.run(primary_cmd, env=ENV, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=15, check=False, close_fds=True)
        if primary.returncode != 0:
            raise RuntimeError(f"primary namespace probe failed rc={primary.returncode}:\n{primary.stdout}")
        if accepted:
            raise RuntimeError("host loopback listener was reachable from sandbox namespace")


        # Gate B: synthetic hostile shim; no real Agent or production credentials.
        shim = r'''set -eu
probe_denied() {
  name="$1"; path="$2"
  if cat "$path"; then echo "FAIL_READ:$name"; exit 51; else echo "DENIED_READ:$name"; fi
}
probe_denied oracle /.oracle/expected.json
probe_denied context /context.json
probe_denied host-root /tmp/host-canary
probe_denied host-proc /proc/1/root/etc/shadow
probe_denied container-socket /run/docker.sock
if touch /work/../../host-write; then echo "FAIL_WRITE_OUTSIDE"; exit 52; else echo "DENIED_WRITE_OUTSIDE"; fi
if echo probe | nc -w 1 127.0.0.1 PORT; then echo "FAIL_HOST_NETWORK"; exit 53; else echo "DENIED_HOST_NETWORK"; fi
[ -z "${HOST_SECRET_CANARY+x}" ] || { echo "FAIL_HOST_ENV"; exit 54; }
echo "PASS_HOST_ENV_HIDDEN"
echo "SCP_SYNTHETIC_SECRET_TOKEN=demo-token-not-real"
echo "SYNTHETIC_SHIM_COMPLETE"
'''
        (root / "adversarial.sh").write_text(shim.replace("PORT", str(port)), encoding="utf-8")
        (root / "adversarial.sh").chmod(0o444)
        shim_cmd = namespace_command(unshare, root, work, ". /adversarial.sh", kill_child=True)
        raw_output, overflow, timed_out, shim_rc = run_capture_limited(shim_cmd, max_bytes=8192, timeout_seconds=8)
        if shim_rc != 0 or overflow or timed_out:
            raise RuntimeError(f"synthetic shim failed rc={shim_rc}, overflow={overflow}, timeout={timed_out}:\\n{raw_output!r}")
        sanitized = redact_synthetic_secret(raw_output)
        evidence_dir = base / "evidence"
        evidence_dir.mkdir(mode=0o700)
        evidence_path = evidence_dir / "synthetic-client-output.redacted.txt"
        evidence_path.write_bytes(sanitized)  # persist only after redaction
        persisted = evidence_path.read_bytes()
        if b"demo-token-not-real" in persisted or b"SCP_SYNTHETIC_SECRET_TOKEN=[REDACTED]" not in persisted:
            raise RuntimeError("synthetic marker was not redacted before persistence")
        required_denials = [b"DENIED_READ:oracle", b"DENIED_READ:context", b"DENIED_READ:host-root",
                            b"DENIED_READ:host-proc", b"DENIED_READ:container-socket",
                            b"DENIED_WRITE_OUTSIDE", b"DENIED_HOST_NETWORK", b"PASS_HOST_ENV_HIDDEN"]
        if any(item not in raw_output for item in required_denials):
            raise RuntimeError(f"synthetic shim missed a denial: {raw_output!r}")
        if accepted:
            raise RuntimeError("host loopback listener was reachable by the synthetic shim")
        stop_accept.set()
        listener.close()
        thread.join(timeout=1)

        # Output-bomb probe: retain at most 4096 bytes and terminate the namespace owner.
        flood_cmd = namespace_command(unshare, root, work,
            "while :; do printf '0123456789abcdef0123456789abcdef'; done", kill_child=True)
        flood_output, flood_overflow, flood_timeout, flood_rc = run_capture_limited(
            flood_cmd, max_bytes=4096, timeout_seconds=5)
        if not flood_overflow or flood_timeout or len(flood_output) != 4096:
            raise RuntimeError(f"output cap failed overflow={flood_overflow} timeout={flood_timeout} bytes={len(flood_output)} rc={flood_rc}")
        if (evidence_dir / "output-bomb.raw").exists():
            raise RuntimeError("raw output-bomb data must not be persisted")

        # Verify PID-namespace teardown kills descendants: child would touch a host-visible
        # scratch marker after 3 seconds; terminate the namespace owner immediately after start.
        (work / "child-started").unlink(missing_ok=True)
        (work / "late-marker").unlink(missing_ok=True)
        child_script = "(sleep 3; touch /work/late-marker) & touch /work/child-started; wait"
        child_cmd = namespace_command(unshare, root, work, child_script, kill_child=True)
        proc = subprocess.Popen(child_cmd, env=ENV, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, close_fds=True)
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline and not (work / "child-started").exists() and proc.poll() is None:
            time.sleep(0.05)
        if not (work / "child-started").exists():
            proc.kill()
            output, _ = proc.communicate(timeout=3)
            raise RuntimeError(f"sandbox child did not start: {output}")
        proc.send_signal(signal.SIGTERM)
        try:
            proc.communicate(timeout=4)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate(timeout=2)
            raise RuntimeError("namespace owner did not terminate")
        time.sleep(3.3)
        if (work / "late-marker").exists():
            raise RuntimeError("descendant survived namespace-owner termination")

        # Deterministic cleanup fault injection: owned resources are quarantined and
        # marked non-reusable when cleanup is reported failed/unknown.
        dummy_root = base / "dummy-root"
        dummy_work = base / "dummy-work"
        dummy_root.mkdir(mode=0o700)
        dummy_work.mkdir(mode=0o700)
        dummy_owner = base / "owners" / "dummy.json"
        write_owner_record(dummy_owner, "dummy-run", dummy_root, dummy_work)
        state = cleanup_owned_paths(base, dummy_owner, "dummy-run", dummy_root, dummy_work, inject_failure=True)
        if state != "quarantined" or owner_record_allows_reuse(dummy_owner):
            raise RuntimeError("cleanup failure did not quarantine and block reuse")
        dummy_record = json.loads(dummy_owner.read_text(encoding="utf-8"))
        shutil.rmtree(dummy_record["quarantine_root"])
        shutil.rmtree(dummy_record["quarantine_work"])
        dummy_owner.unlink()

        cleanup_state = cleanup_owned_paths(base, owner_file, run_id, root, work)
        if cleanup_state != "succeeded" or root.exists() or work.exists() or owner_file.exists():
            raise RuntimeError("owned cleanup did not remove only its resources")

        print("PLATFORM=Linux x86_64")
        print("USER_MOUNT_NET_PID_NAMESPACES=PASS")
        print("UID_GID_DROP=PASS uid=65534 gid=65534")
        print("NO_NEW_PRIVS_AND_CAPABILITY_DROP=PASS")
        print("ROOTFS_READ_ONLY=PASS")
        print("HOST_CANARY_AND_SYMLINK_ESCAPE=PASS (not readable)")
        print("PROC_SYS_HIDDEN=PASS")
        print("DEDICATED_WRITABLE_SCRATCH=PASS")
        print("HOST_LOOPBACK_NETWORK_ISOLATION=PASS")
        print("PID_NAMESPACE_DESCENDANT_TEARDOWN=PASS")
        print("HOST_SECRET_ENV_NOT_INHERITED=PASS")
        print("GATE_B_SYNTHETIC_SHIM_ACCESS_DENIALS=PASS")
        print("OUTPUT_REDACTION_BEFORE_PERSISTENCE=PASS (synthetic marker only)")
        print("OUTPUT_CAPTURE_LIMIT=PASS (4096-byte cap; raw overflow not persisted)")
        print("CLEANUP_OWNERSHIP_AND_QUARANTINE=PASS (synthetic failure injection; quarantined root not reused)")
        print("CLEANUP_NORMAL_PATH=PASS (owned root and scratch removed)")
        print("RESULT=GATE_A_AND_B_CORE_PROBES_PASS; NOT A PRODUCTION SANDBOX CERTIFICATION")
        print("PROBE_OUTPUT_BEGIN")
        print(primary.stdout.rstrip())
        print("PROBE_OUTPUT_END")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"FAIL: {exc}", flush=True)
        raise SystemExit(1)
