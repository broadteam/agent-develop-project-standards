#!/usr/bin/env python3
"""Fail-closed host capability preflight for the SCP Linux sandbox prototype.

This program reports host capabilities; it is not a sandbox and never starts an
Agent.  The default mode performs non-destructive discovery plus a disposable
user/mount/network/PID namespace and seccomp probe.  An explicit --cgroup-root
opts in to creating a temporary, empty child cgroup and writing/reading test
limits there.  No process is moved into that cgroup.
"""
from __future__ import annotations

import argparse
import ctypes
import errno
import json
import os
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import unittest
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

REQUIRED_TOOLS = (
    "python3", "gcc", "gzip", "unshare", "mount", "chroot", "setpriv",
    "prlimit", "ldd", "busybox",
)
REQUIRED_CGROUP_CONTROLLERS = ("cpu", "memory", "pids")


@dataclass
class Check:
    name: str
    status: str
    required_for: str
    evidence: str


class Report:
    def __init__(self) -> None:
        self.checks: list[Check] = []

    def add(self, name: str, status: str, required_for: str, evidence: str) -> None:
        self.checks.append(Check(name, status, required_for, evidence))

    def gate(self, requirement: str) -> str:
        relevant = [c for c in self.checks if requirement in c.required_for.split(",")]
        if any(c.status in ("BLOCKED", "UNAVAILABLE") for c in relevant):
            return "BLOCKED"
        if any(c.status == "NOT_VERIFIED" for c in relevant):
            return "NOT_VERIFIED"
        return "PASS" if relevant and all(c.status == "PASS" for c in relevant) else "NOT_VERIFIED"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": "scp-host-preflight/1.0",
            "generated_at_unix": int(time.time()),
            "host": {
                "system": platform.system(),
                "release": platform.release(),
                "machine": platform.machine(),
                "python": platform.python_version(),
                "effective_uid": os.geteuid() if hasattr(os, "geteuid") else None,
            },
            "gates": {
                "prototype_runtime": self.gate("prototype"),
                "production_host_controls": self.gate("production"),
            },
            "checks": [asdict(c) for c in self.checks],
            "interpretation": {
                "prototype_runtime": "Host capability evidence only; does not certify a Runner or Agent sandbox.",
                "production_host_controls": "Must be PASS before production review; this report alone never authorizes production use.",
            },
        }


def unescape_mountinfo(value: str) -> str:
    return value.replace("\\040", " ").replace("\\011", "\t").replace("\\012", "\n").replace("\\134", "\\")


def parse_cgroup2_mounts(mountinfo: str) -> list[dict[str, str]]:
    mounts: list[dict[str, str]] = []
    for line in mountinfo.splitlines():
        if " - " not in line:
            continue
        left, right = line.split(" - ", 1)
        before, after = left.split(), right.split()
        if len(before) < 6 or len(after) < 3 or after[0] != "cgroup2":
            continue
        mounts.append({
            "root": unescape_mountinfo(before[3]),
            "mountpoint": unescape_mountinfo(before[4]),
            "options": before[5],
            "super_options": ",".join(after[2:]),
        })
    return mounts


def parse_unified_cgroup(cgroup_text: str) -> str | None:
    for line in cgroup_text.splitlines():
        parts = line.split(":", 2)
        if len(parts) == 3 and parts[0] == "0" and parts[1] == "":
            return parts[2]
    return None


def parse_tokens(text: str) -> set[str]:
    return {token for token in text.replace("\n", " ").split() if token}


def find_self_cgroup_dir(mounts: list[dict[str, str]], cgroup_path: str) -> Path | None:
    if not cgroup_path or not cgroup_path.startswith("/"):
        return None
    for mount in mounts:
        root = mount["root"].rstrip("/") or "/"
        if root != "/" and cgroup_path != root and not cgroup_path.startswith(root + "/"):
            continue
        suffix = cgroup_path[len(root):].lstrip("/") if root != "/" else cgroup_path.lstrip("/")
        return Path(mount["mountpoint"]) / suffix
    return None


def run_probe(command: list[str], timeout: int = 12) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=timeout, check=False, close_fds=True)


def probe_namespace() -> tuple[str, str]:
    unshare = shutil.which("unshare")
    if not unshare:
        return "BLOCKED", "unshare executable not found"
    child = r'''import os, pathlib, subprocess, tempfile, shutil, sys
assert os.geteuid() == 0, "mapped user namespace did not become uid 0"
assert os.getegid() == 0, "mapped user namespace did not become gid 0"
assert os.getpid() == 1, f"PID namespace init expected pid 1, got {os.getpid()}"
uid_map = pathlib.Path('/proc/self/uid_map').read_text().strip()
gid_map = pathlib.Path('/proc/self/gid_map').read_text().strip()
assert uid_map and gid_map, "uid/gid maps are empty"
subprocess.run(['mount', '--make-rprivate', '/'], check=True, stdout=subprocess.DEVNULL)
with tempfile.TemporaryDirectory(prefix='scp-preflight-') as td:
    mountpoint = pathlib.Path(td) / 'mnt'
    mountpoint.mkdir()
    subprocess.run(['mount', '-t', 'tmpfs', '-o', 'size=1m,nosuid,nodev,noexec', 'tmpfs', str(mountpoint)], check=True, stdout=subprocess.DEVNULL)
    try:
        entries = pathlib.Path('/proc/self/mountinfo').read_text().splitlines()
        matching = [line for line in entries if str(mountpoint) in line and ' - tmpfs ' in line]
        assert matching, "tmpfs mount not visible in mountinfo"
        route = pathlib.Path('/proc/net/route').read_text().splitlines()[1:]
        defaults = [line for line in route if len(line.split()) > 1 and line.split()[1] == '00000000']
        assert not defaults, f"default IPv4 route exposed in isolated netns: {defaults}"
        ipv6_routes = pathlib.Path('/proc/net/ipv6_route').read_text().splitlines()
        ipv6_defaults = [line for line in ipv6_routes if line.split() and line.split()[0] == '0' * 32 and line.split()[1] == '00' and line.split()[-1] != 'lo']
        assert not ipv6_defaults, f"default IPv6 route exposed in isolated netns: {ipv6_defaults}"
        interfaces = {line.split(':', 1)[0].strip() for line in pathlib.Path('/proc/net/dev').read_text().splitlines()[2:]}
        assert interfaces == {'lo'}, f"unexpected network interfaces in isolated netns: {sorted(interfaces)}"
    finally:
        subprocess.run(['umount', str(mountpoint)], check=True, stdout=subprocess.DEVNULL)
print('USER_MOUNT_NET_PID_TMPFS=PASS')
'''
    command = [unshare, "--user", "--map-root-user", "--mount", "--net", "--pid", "--fork",
               sys.executable, "-c", child]
    try:
        result = run_probe(command, timeout=15)
    except subprocess.TimeoutExpired:
        return "BLOCKED", "namespace + tmpfs probe exceeded 15 seconds"
    if result.returncode == 0 and "USER_MOUNT_NET_PID_TMPFS=PASS" in result.stdout:
        return "PASS", "user/mount/network/PID namespaces, UID/GID maps, private propagation, tmpfs mount/unmount and no default IPv4 route verified in disposable namespace"
    detail = (result.stderr or result.stdout).strip().replace("\n", " | ")
    return "BLOCKED", f"unshare probe exit={result.returncode}: {detail[:900]}"


def probe_seccomp() -> tuple[str, str]:
    child = r'''import ctypes, errno, os, sys
libc = ctypes.CDLL(None, use_errno=True)
class SockFilter(ctypes.Structure):
    _fields_ = [('code', ctypes.c_ushort), ('jt', ctypes.c_ubyte), ('jf', ctypes.c_ubyte), ('k', ctypes.c_uint)]
class SockFprog(ctypes.Structure):
    _fields_ = [('len', ctypes.c_ushort), ('filter', ctypes.POINTER(SockFilter))]
insn = SockFilter(0x06, 0, 0, 0x7fff0000)  # BPF_RET | BPF_K, SECCOMP_RET_ALLOW
prog = SockFprog(1, ctypes.pointer(insn))
if libc.prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
    e = ctypes.get_errno(); raise OSError(e, os.strerror(e))
if libc.prctl(22, 2, ctypes.byref(prog), 0, 0) != 0:  # PR_SET_SECCOMP, FILTER
    e = ctypes.get_errno(); raise OSError(e, os.strerror(e))
mode = libc.prctl(21, 0, 0, 0, 0)  # PR_GET_SECCOMP
if mode != 2: raise RuntimeError(f'expected seccomp filter mode 2, got {mode}')
print('SECCOMP_FILTER_INSTALL=PASS')
'''
    try:
        result = run_probe([sys.executable, "-c", child], timeout=5)
    except subprocess.TimeoutExpired:
        return "BLOCKED", "seccomp self-probe exceeded 5 seconds"
    if result.returncode == 0 and "SECCOMP_FILTER_INSTALL=PASS" in result.stdout:
        return "PASS", "disposable child successfully set no_new_privs, installed classic BPF filter and read back SECCOMP_MODE_FILTER"
    detail = (result.stderr or result.stdout).strip().replace("\n", " | ")
    return "BLOCKED", f"seccomp filter install exit={result.returncode}: {detail[:700]}"


def probe_landlock() -> tuple[str, str]:
    if platform.machine().lower() not in ("x86_64", "amd64"):
        return "NOT_VERIFIED", "Landlock syscall number is not defined by this x86_64-only probe"
    libc = ctypes.CDLL(None, use_errno=True)
    # landlock_create_ruleset(NULL, 0, LANDLOCK_CREATE_RULESET_VERSION)
    result = libc.syscall(444, ctypes.c_void_p(), ctypes.c_size_t(0), ctypes.c_uint(1))
    if result >= 1:
        return "PASS", f"Landlock ABI version {result} is available; this probe does not install a policy"
    err = ctypes.get_errno()
    if err == errno.ENOSYS:
        return "UNAVAILABLE", "landlock_create_ruleset returned ENOSYS"
    if err in (errno.EOPNOTSUPP, errno.EPERM, errno.EACCES):
        return "BLOCKED", f"Landlock version query denied/unavailable: {errno.errorcode.get(err, err)}"
    return "NOT_VERIFIED", f"Landlock version query returned {errno.errorcode.get(err, err)} ({err})"


def inspect_lsm() -> tuple[str, str]:
    evidence: list[str] = []
    lsm_path = Path("/sys/kernel/security/lsm")
    try:
        names = parse_tokens(lsm_path.read_text())
        evidence.append("active_lsm=" + ",".join(sorted(names)))
    except OSError as exc:
        evidence.append(f"/sys/kernel/security/lsm unreadable: {exc.__class__.__name__}")
    apparmor_enabled = Path("/sys/module/apparmor/parameters/enabled")
    try:
        evidence.append("apparmor_enabled=" + apparmor_enabled.read_text().strip())
    except OSError:
        pass
    selinux_enforce = Path("/sys/fs/selinux/enforce")
    try:
        evidence.append("selinux_enforce=" + selinux_enforce.read_text().strip())
    except OSError:
        pass
    attr = Path("/proc/self/attr/current")
    try:
        evidence.append("current_label=" + attr.read_text().strip()[:160])
    except OSError:
        pass
    return "NOT_VERIFIED", ("; ".join(evidence) if evidence else "No readable LSM state interface; policy cannot be audited by this probe") + "; an enabled LSM is not proof that the required sandbox policy is loaded and correct"


def probe_cgroup(cgroup_root: str | None) -> tuple[str, str]:
    try:
        mountinfo = Path("/proc/self/mountinfo").read_text()
        cgroup_text = Path("/proc/self/cgroup").read_text()
    except OSError as exc:
        return "BLOCKED", f"cannot inspect cgroup topology: {exc}"
    mounts = parse_cgroup2_mounts(mountinfo)
    if not mounts:
        return "BLOCKED", "no cgroup v2 mount found in /proc/self/mountinfo"
    if cgroup_root:
        root = Path(cgroup_root).resolve()
        mount_roots = [Path(m["mountpoint"]).resolve() for m in mounts]
        if not any(root == m or m in root.parents for m in mount_roots):
            return "BLOCKED", f"--cgroup-root {root} is not beneath a discovered cgroup v2 mount"
        return probe_delegated_cgroup_root(root)
    self_path = parse_unified_cgroup(cgroup_text)
    candidate = find_self_cgroup_dir(mounts, self_path or "")
    if candidate is None:
        return "BLOCKED", "unified cgroup path could not be mapped to a cgroup2 mount"
    try:
        available = parse_tokens((candidate / "cgroup.controllers").read_text())
        enabled = parse_tokens((candidate / "cgroup.subtree_control").read_text())
        readonly = bool(os.statvfs(candidate).f_flag & getattr(os, "ST_RDONLY", 1))
    except OSError as exc:
        return "BLOCKED", f"cannot inspect current cgroup directory {candidate}: {exc}"
    missing = sorted(set(REQUIRED_CGROUP_CONTROLLERS) - available)
    not_enabled = sorted(set(REQUIRED_CGROUP_CONTROLLERS) - enabled)
    if readonly:
        return "BLOCKED", f"cgroup v2 hierarchy is read-only at {candidate}; available={sorted(available)}; subtree_control={sorted(enabled)}"
    if missing or not_enabled:
        return "BLOCKED", f"delegated cpu/memory/pids controllers unavailable or not enabled; missing={missing}; not_enabled={not_enabled}; path={candidate}; supply an explicitly delegated --cgroup-root to perform an isolated write probe"
    return "NOT_VERIFIED", f"controllers appear enabled at {candidate}, but no write probe was attempted; pass --cgroup-root to create and remove an empty temporary child cgroup"


def probe_delegated_cgroup_root(root: Path) -> tuple[str, str]:
    try:
        available = parse_tokens((root / "cgroup.controllers").read_text())
        enabled = parse_tokens((root / "cgroup.subtree_control").read_text())
        missing = sorted(set(REQUIRED_CGROUP_CONTROLLERS) - available)
        not_enabled = sorted(set(REQUIRED_CGROUP_CONTROLLERS) - enabled)
        if missing or not_enabled:
            return "BLOCKED", f"delegated root controller check failed; missing={missing}; not_enabled={not_enabled}; root={root}"
        child = root / f".scp-preflight-{os.getpid()}-{time.time_ns()}"
        os.mkdir(child, 0o700)
        try:
            limits = {"cpu.max": "10000 100000\n", "memory.max": str(16 * 1024 * 1024) + "\n", "pids.max": "16\n"}
            readback: dict[str, str] = {}
            for filename, value in limits.items():
                target = child / filename
                target.write_text(value)
                readback[filename] = target.read_text().strip()
                if not readback[filename]:
                    raise RuntimeError(f"empty readback for {filename}")
            if readback["cpu.max"] != "10000 100000":
                raise RuntimeError(f"unexpected cpu.max readback {readback['cpu.max']!r}")
            if int(readback["memory.max"]) != 16 * 1024 * 1024 or int(readback["pids.max"]) != 16:
                raise RuntimeError(f"unexpected cgroup limit readback: {readback}")
        finally:
            os.rmdir(child)
        return "PASS", f"empty child cgroup created; cpu.max/memory.max/pids.max write+readback passed; child removed; no process was migrated; root={root}; readback={readback}"
    except Exception as exc:
        return "BLOCKED", f"delegated cgroup write probe failed: {exc.__class__.__name__}: {exc}"


def run_self_tests() -> int:
    class ParserTests(unittest.TestCase):
        def test_mountinfo_escapes(self) -> None:
            self.assertEqual(unescape_mountinfo(r"/sys/fs/cgroup/a\040b"), "/sys/fs/cgroup/a b")

        def test_cgroup2_mount_parser(self) -> None:
            text = "31 25 0:28 /delegated /sys/fs/cgroup rw,nosuid - cgroup2 cgroup2 rw,nsdelegate\n"
            parsed = parse_cgroup2_mounts(text)
            self.assertEqual(parsed[0]["root"], "/delegated")
            self.assertEqual(parsed[0]["mountpoint"], "/sys/fs/cgroup")

        def test_unified_cgroup(self) -> None:
            self.assertEqual(parse_unified_cgroup("12:cpu:/legacy\n0::/user.slice/job\n"), "/user.slice/job")
            self.assertIsNone(parse_unified_cgroup("12:cpu:/legacy\n"))

        def test_find_self_cgroup_dir_with_mount_root(self) -> None:
            mounts = [{"root": "/delegated", "mountpoint": "/sys/fs/cgroup", "options": "rw", "super_options": "rw"}]
            self.assertEqual(str(find_self_cgroup_dir(mounts, "/delegated/a/b")), "/sys/fs/cgroup/a/b")
            self.assertIsNone(find_self_cgroup_dir(mounts, "/elsewhere"))

        def test_controller_tokens(self) -> None:
            self.assertEqual(parse_tokens("cpu memory\npids\n"), {"cpu", "memory", "pids"})

        def test_gate_fails_closed(self) -> None:
            r = Report()
            r.add("x", "PASS", "prototype", "ok")
            r.add("cgroup", "BLOCKED", "production", "no delegate")
            r.add("lsm", "NOT_VERIFIED", "production", "no audit")
            self.assertEqual(r.gate("prototype"), "PASS")
            self.assertEqual(r.gate("production"), "BLOCKED")

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ParserTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


def build_report(cgroup_root: str | None) -> Report:
    report = Report()
    system = platform.system()
    machine = platform.machine().lower()
    report.add("platform", "PASS" if system == "Linux" and machine in ("x86_64", "amd64") else "BLOCKED",
               "prototype,production", f"system={system}; machine={machine}; required=Linux x86_64")
    uid = os.geteuid() if hasattr(os, "geteuid") else -1
    report.add("effective_uid", "PASS" if uid == 0 else "BLOCKED", "prototype,production",
               f"effective_uid={uid}; this prototype currently requires root to establish explicit UID/GID maps")
    missing_tools = [tool for tool in REQUIRED_TOOLS if not shutil.which(tool)]
    report.add("required_tools", "PASS" if not missing_tools else "BLOCKED", "prototype,production",
               "all required tools found" if not missing_tools else "missing=" + ",".join(missing_tools))
    try:
        stat_text = Path("/proc/self/stat").read_text()
        status_text = Path("/proc/self/status").read_text()
        proc_entries = os.listdir("/proc")
        if not stat_text or "NSpid:" not in status_text or not any(entry.isdigit() for entry in proc_entries):
            raise RuntimeError("/proc process metadata or PID enumeration incomplete")
        proc_status, proc_evidence = "PASS", "/proc/self/stat and NSpid metadata readable; /proc PID directory enumeration available"
    except Exception as exc:
        proc_status, proc_evidence = "BLOCKED", f"/proc inspection unavailable: {exc}"
    report.add("proc_inspection", proc_status, "prototype,production", proc_evidence)
    ns_status, ns_evidence = probe_namespace()
    report.add("namespace_and_tmpfs", ns_status, "prototype,production", ns_evidence)
    sec_status, sec_evidence = probe_seccomp()
    report.add("seccomp_filter", sec_status, "prototype,production", sec_evidence)
    cg_status, cg_evidence = probe_cgroup(cgroup_root)
    report.add("cgroup_v2_delegation", cg_status, "production", cg_evidence)
    ll_status, ll_evidence = probe_landlock()
    report.add("landlock_capability", ll_status, "diagnostic", ll_evidence)
    lsm_status, lsm_evidence = inspect_lsm()
    report.add("lsm_policy_audit", lsm_status, "production", lsm_evidence)
    report.add("host_socket_and_egress_policy", "NOT_VERIFIED", "production",
               "must be verified against the final mount plan and network policy: no host runtime socket bind-mount, no host-network/host-loopback route, explicit egress allow-list; host capability probing cannot prove future mount configuration")
    report.add("client_syscall_policy", "NOT_VERIFIED", "production",
               "current prototype uses an x86_64 seccomp denylist with default ALLOW; production requires a client-version-pinned, reviewed allowlist and regression corpus")
    report.add("general_secret_handling", "NOT_VERIFIED", "production",
               "current prototype redacts one synthetic marker only; production requires a documented secret model and pre-persistence scanner/redaction tests")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    parser.add_argument("--strict-production", action="store_true", help="exit 3 unless every production host control is PASS")
    parser.add_argument("--cgroup-root", help="explicit delegated cgroup v2 directory; performs a temporary empty-child write/readback probe")
    parser.add_argument("--self-test", action="store_true", help="run parser and fail-closed gate unit tests")
    args = parser.parse_args()
    if args.self_test:
        return run_self_tests()
    report = build_report(args.cgroup_root)
    data = report.as_dict()
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print("SCP Linux Host Preflight 1.0")
        print(f"Host: {data['host']['system']} {data['host']['release']} / {data['host']['machine']} / euid={data['host']['effective_uid']}")
        for check in report.checks:
            print(f"{check.status:13} {check.name:32} {check.evidence}")
        print("-" * 78)
        print("Prototype runtime gate:       " + data["gates"]["prototype_runtime"])
        print("Production host-controls gate: " + data["gates"]["production_host_controls"])
        print("This report is not production security acceptance or authorization.")
    if args.strict_production and data["gates"]["production_host_controls"] != "PASS":
        return 3
    return 0 if data["gates"]["prototype_runtime"] == "PASS" else 2


if __name__ == "__main__":
    sys.exit(main())
